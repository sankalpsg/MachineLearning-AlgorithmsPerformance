This is the readme file for task 3 submitted by team_26

1. Before executing the task, configure the 'config.py' file as per instructions given in the config file.
2. To execute the code, execute the 'main.py' python file from the console/command prompt.
3. Wait for the output on the console.

